public class CoffeeMakerObserver implements Observer {
    @Override
    public String update(String state) {
        return "State changed to "+ state;
    }
}
