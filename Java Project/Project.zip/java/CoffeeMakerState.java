public interface CoffeeMakerState {
    void start(CoffeeMaker cm);
    void filled(CoffeeMaker cm, int cups);
    void reset(CoffeeMaker cm);
}
