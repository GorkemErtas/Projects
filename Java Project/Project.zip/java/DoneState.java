import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
public class DoneState implements CoffeeMakerState {
    public DoneState(CoffeeMaker cm) {
        cm.setDone();
    }
    @Override
    public void start(CoffeeMaker cm) {
        System.out.println("Coffee maker is already DONE.");
    }

    @Override
    public void filled(CoffeeMaker cm, int cups) {
        System.out.println("Cannot fill cups after brewing is done.");
    }

    @Override
    public void reset(CoffeeMaker cm) {
        cm.setState(new EmptyState(cm));
        System.out.println("Coffee maker is now EMPTY.");
        int cups = cm.getCups();
        String formattedDate = formatDate(new Date());
        cm.setMessages("Inserted to db Cups=" + cups + ", Date=" + formattedDate);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/SE3313Project";
            String username = "root";
            String password = "Gorkemfb2002";

            try (Connection connection = DriverManager.getConnection(url, username, password)) {
                insertDataIntoDatabase(connection, cups);
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private void insertDataIntoDatabase(Connection connection, int cups) throws SQLException {

        String query = "INSERT INTO se3313project.tc (cupsnum, cd) VALUES (?, ?);";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, cups);
            preparedStatement.setDate(2, new java.sql.Date(Calendar.getInstance().getTime().getTime()));
            preparedStatement.executeUpdate();
        }
    }

    private String formatDate(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        return dateFormat.format(date);
    }
}
