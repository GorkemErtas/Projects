public interface Observer {
    String update(String msg);
}
