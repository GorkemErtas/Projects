import java.util.Timer;

public class IdleState implements CoffeeMakerState {
    public IdleState(CoffeeMaker cm) {
        cm.setIdle();
    }
    @Override
    public void start(CoffeeMaker cm) {
        System.out.println("Coffee maker is now BREWING.");
        Timer timer = new Timer();
        cm.setState(new BrewingState(cm, timer));
        timer.schedule(new BrewAction(cm), 5000);
    }

    @Override
    public void filled(CoffeeMaker cm, int cups) {
        System.out.println("Coffee maker is already IDLE.");
    }

    @Override
    public void reset(CoffeeMaker cm) {
        cm.setState(new EmptyState(cm));
        System.out.println("Coffee maker is now EMPTY.");
    }
}
