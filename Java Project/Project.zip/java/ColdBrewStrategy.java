public class ColdBrewStrategy implements BrewStrategy {
    @Override
    public void brew() {
        System.out.println("Brewing cold coffee");
    }
}
