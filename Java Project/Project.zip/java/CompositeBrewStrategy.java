import java.util.ArrayList;
import java.util.List;
public class CompositeBrewStrategy implements BrewStrategy {
    private final List<BrewStrategy> strategies = new ArrayList<>();
    public void addStrategy(BrewStrategy str) {
        strategies.add(str);
    }

    @Override
    public void brew() {
        for (BrewStrategy str : strategies) {
            str.brew();
        }
    }
}
