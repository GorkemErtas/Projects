public interface BrewStrategy {
    void brew();
}
