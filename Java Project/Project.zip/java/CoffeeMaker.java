import java.awt.Color;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CoffeeMaker extends javax.swing.JFrame {
    private BrewStrategy brewStrategy;
    private List<Observer> observers = new ArrayList<>();
    private CoffeeMakerState currentState;
    private int cups;
    public CoffeeMaker() {
        initComponents();
        pageinit();
    }
    public void setBrewStrategy(BrewStrategy brewStrategy) {
        this.brewStrategy = brewStrategy;
    }

    public BrewStrategy getBrewStrategy() {
        return brewStrategy;
    }
    public int getCups() {
        return cups;
    }

    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    public void notifyObservers() {

        for (Observer observer : observers) {
            messages.setText(observer.update(currentState.toString()));
        }
    }

    public void brew() {
        brewStrategy.brew();
    }
    public void setState(CoffeeMakerState state) {
        currentState = state;
        notifyObservers();
    }

    public void setMessages(String message){
        messages.setText(message);
    }

    public void setIdle() {
        idle.setBackground(Color.yellow);
        brewing.setBackground(Color.white);
        done.setBackground(Color.white);
    }
    public void setBrewing() {
        idle.setBackground(Color.white);
        brewing.setBackground(Color.yellow);
        done.setBackground(Color.white);
    }
    public void setDone() {
        idle.setBackground(Color.white);
        brewing.setBackground(Color.white);
        done.setBackground(Color.yellow);
    }
    public void setEmpty() {
        idle.setBackground(Color.white);
        brewing.setBackground(Color.white);
        done.setBackground(Color.white);
    }
    public void pageinit(){
        addObserver(new CoffeeMakerObserver());
        setBrewStrategy(new ColdBrewStrategy());
        currentState = new EmptyState(this);
    }

    @SuppressWarnings("unchecked")

    private void initComponents() {

        filled = new javax.swing.JButton();
        start = new javax.swing.JButton();
        totalCups = new javax.swing.JButton();
        filledCupsText = new javax.swing.JTextField();
        idle = new javax.swing.JTextField();
        brewing = new javax.swing.JTextField();
        done = new javax.swing.JTextField();
        totalCupsText = new javax.swing.JTextField();
        reset = new javax.swing.JButton();
        messages = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        filled.setText("FILLED");
        filled.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filledActionPerformed(evt);
            }
        });

        start.setText("START");
        start.setMaximumSize(new java.awt.Dimension(90, 55));
        start.setMinimumSize(new java.awt.Dimension(90, 55));
        start.setPreferredSize(new java.awt.Dimension(90, 55));
        start.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startActionPerformed(evt);
            }
        });

        totalCups.setText("Total Cups");
        totalCups.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalCupsActionPerformed(evt);
            }
        });

        filledCupsText.setText("0");

        idle.setText("IDLE");

        brewing.setText("BREWING");

        done.setText("DONE");

        totalCupsText.setText("0");
        totalCupsText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalCupsTextActionPerformed(evt);
            }
        });

        reset.setText("Reset");
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });

        messages.setText("Messages/Warnings…");
        messages.setToolTipText("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(reset, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addComponent(filled, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addComponent(start, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addComponent(totalCups))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(filledCupsText)
                                                        .addComponent(idle)
                                                        .addComponent(brewing, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
                                                        .addComponent(done)
                                                        .addComponent(totalCupsText)))
                                        .addComponent(messages))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(filled)
                                        .addComponent(filledCupsText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(idle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(brewing, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(9, 9, 9)
                                                .addComponent(done, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(start, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(totalCupsText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(totalCups))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(reset)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(messages, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pack();
    }

    private void filledActionPerformed(java.awt.event.ActionEvent evt) {
        cups = Integer.parseInt(filledCupsText.getText());
        currentState.filled(this,cups);

    }

    private void startActionPerformed(java.awt.event.ActionEvent evt) {
        currentState.start(this);
    }

    private void totalCupsActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return;
        }

        String jdbcUrl = "jdbc:mysql://localhost:3306/SE3313Project";
        String username = "root";
        String password = "Gorkemfb2002";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {

            LocalDate currentDate = LocalDate.now();
            LocalDate firstDayOfLastMonth = currentDate.minusMonths(1).withDayOfMonth(1);

            String query = "SELECT SUM(cupsnum) AS total_cups FROM SE3313Project.tc WHERE cd >= ?;";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                preparedStatement.setDate(1, java.sql.Date.valueOf(firstDayOfLastMonth));

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next() ) {
                        int totalCups = resultSet.getInt("total_cups");
                        totalCupsText.setText(String.valueOf(totalCups));
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void totalCupsTextActionPerformed(java.awt.event.ActionEvent evt) {
    }

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {
        messages.setText("Messages/Warnings…");
        filledCupsText.setText("0");
        currentState.reset(this);
    }

    private javax.swing.JTextField brewing;
    private javax.swing.JTextField done;
    private javax.swing.JButton filled;
    private javax.swing.JTextField filledCupsText;
    private javax.swing.JTextField idle;
    private javax.swing.JTextField messages;
    private javax.swing.JButton reset;
    private javax.swing.JButton start;
    private javax.swing.JButton totalCups;
    private javax.swing.JTextField totalCupsText;
}
