import java.util.Timer;

public class EmptyState implements CoffeeMakerState {
    public EmptyState(CoffeeMaker cm) {
        cm.setEmpty();
    }
    @Override
    public void start(CoffeeMaker cm) {
        System.out.println("Warning: Coffee maker is empty. Fill it first!");
        Timer timer = new Timer();
        cm.setState(new BrewingState(cm, timer));
        timer.schedule(new BrewAction(cm), 3000);
    }

    @Override
    public void filled(CoffeeMaker cm, int cups) {
        cm.setState(new IdleState(cm));
        System.out.println("Coffee maker is now IDLE.");
    }

    @Override
    public void reset(CoffeeMaker cm) {
        System.out.println("Coffee maker is already empty.");
    }
}
