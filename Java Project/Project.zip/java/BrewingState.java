import java.util.Timer;

public class BrewingState implements CoffeeMakerState {
    private final Timer timer;

    public BrewingState(CoffeeMaker cm, Timer timer) {
        cm.setBrewing();
        this.timer = timer;
    }
    @Override
    public void start(CoffeeMaker cm) {
        System.out.println("Coffee maker is already BREWING.");
    }
    @Override
    public void filled(CoffeeMaker cm, int cups) {
        System.out.println("Cannot fill cups while brewing.");
    }
    @Override
    public void reset(CoffeeMaker cm) {
        timer.cancel();
        cm.setState(new EmptyState(cm));
        System.out.println("Coffee maker is now EMPTY.");
    }
}
