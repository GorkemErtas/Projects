import java.util.TimerTask;

public class BrewAction extends TimerTask {
    CoffeeMaker cm;
    public BrewAction(CoffeeMaker cm) {
        this.cm = cm;
    }

    @Override
    public void run() {
        cm.setState(new DoneState(cm));
    }
}
